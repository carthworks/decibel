import 'bootstrap';
import './scss/app.scss';

/*document.write('welcome to my app');*/
console.log('app loaded');

/*webpack app.js -o bundle.js*/
